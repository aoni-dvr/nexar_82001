/******************************************************************************/
/*  Copyright 2019 Ambarella Inc.                                             */
/*  Author: Peter Weng                                                        */
/*  Email:  cyweng@ambarella.com                                              */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "aes.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

typedef unsigned int uint32_t;
typedef unsigned char uint8_t;

// key to encode license
uint8_t iv[]  = { 0xf1, 0xe1, 0xd2, 0xc3, 0xb4, 0xa5, 0x96, 0x87, 0x78, 0x69, 0x5a, 0x4b, 0x3c, 0x2d, 0x1e, 0x0f };
uint8_t key[] = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef, 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef };

int main(int argc, char** argv) {

    uint32_t i;

    uint8_t tmp[16];
	uint32_t* p32;
    AES_ctx ctx;

    // a very weak kay protect... try a public key system for better key protection
    for (i=0 ; i<16 ; i++){
        key[i] = key[i]^iv[i];
    }
    AES_init_ctx_iv(&ctx, key, iv);

    FILE *fp;
        
    p32 = (uint32_t*)tmp;
	if (argc==1) {
		p32[0] = 0xBABEB1B1;
		p32[1] = 0xBABEB1B1;
		p32[2] = 0xBABEB1B1;
		p32[3] = 0xBABEB1B1;
		printf("usage: license_gen [UUID[0]] [UUID[1]] [UUID[2]] [UUID[3]]\n");
	} else {
		p32[0] = strtol(argv[1], NULL, 16);
		p32[1] = strtol(argv[2], NULL, 16);
		p32[2] = strtol(argv[3], NULL, 16);
		p32[3] = strtol(argv[4], NULL, 16);
	}
	
    printf("generate license for UUID:\n");
	printf("0x%8X ", p32[0]);
	printf("0x%8X ", p32[1]);
	printf("0x%8X ", p32[2]);
	printf("0x%8X\n", p32[3]);
    AES_init_ctx_iv(&ctx, key, iv);
    AES_CBC_encrypt_buffer(&ctx, (uint8_t*)p32, 16);

    fp = fopen("license.bin", "wb");
    fwrite(p32, 16, 1, fp);
    fclose(fp);

    printf("license file generated.\n");
	return 0;
}

