1. Description
AmbaUSB is a utility designed to download firmware
to Ambarella's development board; This is a replacement of DirectUSB.

2. Building and Installation
Linux)
  1. mkdir build
  2. cd build
  3. x86)
     qmake-qt5 ../AmbaUSB.pro -r CONFIG+=release                 \
                                 PREFIX=/usr/local               \
                                 ARCH=i686                       \
                                 UDEV_RULE_DIR=/lib/udev/rules.d \
                                 -spec linux-g++-32
     x86_64)
     qmake-qt5 ../AmbaUSB.pro -r CONFIG+=release                 \
                                 PREFIX=/usr/local               \
                                 ARCH=x86_64                     \
                                 UDEV_RULE_DIR=/lib/udev/rules.d \
                                 -spec linux-g++-64
  4. make
  5. make install
  Note: step 5 needs root privilege;
  You can also use prebuild rpm or deb package.

MacOS)
  1. mkdir build
  2. cd build
  3. qmake ../AmbaUSB.pro -r CONFIG+=x86_64        \
                             PREFIX=$(pwd)/release \
                             -spec macx-clang
  4. make
  5. make install
  After building, you can find AmbaUSB-$(version)-MacOS.dmg at current folder.

Windows7 And Above)
  1. mkdir windows
  2. cd windows
  3. x86)
     mingw32-qmake-qt5 ../AmbaUSB.pro -r PREFIX=$(pwd)/AmbaUSB-win32-release \
                                         ARCH=i686                           \
                                         CONFIG+=release                     \
                                         USB_DRV=libusb0                     \
                                         -spec mingw-w64-g++

     x86_64)
     mingw64-qmake-qt5 ../AmbaUSB.pro -r PREFIX=$(pwd)/AmbaUSB-win64-release \
                                         ARCH=x86_64                         \
                                         CONFIG+=release                     \
                                         USB_DRV=libusb0                     \
                                         -spec mingw-w64-g++
  4. make
  5. make install

Windows XP)
  1. mkdir windows
  2. cd windows
  3. x86)
     mingw32-qmake-qt5 ../AmbaUSB.pro -r PREFIX=$(pwd)/AmbaUSB-win32-release \
                                         ARCH=i686                           \
                                         CONFIG+=release                     \
                                         USB_DRV=libusb0                     \
                                         LEGACY=true                         \
                                         -spec mingw-w64-g++
     x86_64)
     mingw64-qmake-qt5 ../AmbaUSB.pro -r PREFIX=$(pwd)/AmbaUSB-win64-release \
                                         ARCH=x86_64                         \
                                         CONFIG+=release                     \
                                         USB_DRV=libusb0                     \
                                         LEGACY=true                         \
                                         -spec mingw-w64-g++
  4. make
  5. make install

3. Requirements
Linux)
    run command:
    sudo dnf install libusbx-devel qt5-qtbase-devel    \
                     qt5-qtmultimedia-devel zlib-devel \
                     gcc-c++
    to install build dependencies.

MacOS)
    MacOS developer tools, including xcode and compiler
    install Qt at https://www.qt.io/download-open-source/
    install brew at http://brew.sh
    run command:
      brew install homebrew/dupes/zlib
      brew install libusb --HEAD
    to install zlib and libusb

Windows)
    This source code can only be built in Linux MinGW development environemnt.
    The following packages are needed to build AmbaUSB for Windows.
    mingw32 and mingw64 building environemnt in Fedora Linux
    qt-tools qt(Qt version 5) zlib libusbx for both mingw32 and mingw64.
    You can run command:
    sudo dnf install mingw{32,64}-libusbx mingw{32,64}-zlib \
                     mingw{32,64}-qt5-qtbase-devel \
                     mingw{32,64}-qt5-qtmultimedia \
                     mingw{32,64}-qt5-qmake
    to install these packages.
